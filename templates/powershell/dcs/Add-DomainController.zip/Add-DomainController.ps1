Configuration Add-DomainController
{
    Param
    (
        [Parameter(Mandatory)]
        [String] $domainFQDN,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $adminCredential,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $domainCredential

    )

    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'PSDscResources'
    Import-DscResource -ModuleName 'ComputerManagementDsc'

    node localhost
    {
        RemoteDesktopAdmin RemoteDesktopSettings
        {
            IsSingleInstance = 'yes'
            Ensure = 'Present'
            UserAuthentication = 'NonSecure'
        }

        WindowsFeature 'InstallADDomainServicesFeature'
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }

        WindowsFeature 'InstallADDSTools'
        {
            Ensure = 'Present'
            Name = 'RSAT-ADDS-Tools'
            DependsOn = '[WindowsFeature]InstallADDomainServicesFeature'
        }

        WindowsFeature 'RSATADPowerShell'
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-PowerShell'
            DependsOn = '[WindowsFeature]InstallADDSTools'
        }

        WaitForADDomain 'WaitForestAvailability'
        {
            DomainName = $domainFQDN
            Credential = $adminCredential
            DependsOn = '[WindowsFeature]RSATADPowerShell'
        }

        ADDomainController 'DomainControllerMinimal'
        {
            DomainName = $domainFQDN
            Credential = $domainCredential
            SafeModeAdministratorPassword = $adminCredential

            DependsOn = '[WaitForADDomain]WaitForestAvailability'
        }
    }
}