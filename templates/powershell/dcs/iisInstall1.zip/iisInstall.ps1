configuration IISInstall
{


    node "localhost"
    {


        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = @("Web-Server","Web-Mgmt-Tools")
        }


	WindowsFeature Telnet
        {
            Ensure = "Present"
            Name   = "Telnet-Client"
        }


    }



}