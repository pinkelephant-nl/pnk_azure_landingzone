configuration IISInstall
{

# Create default folders
#new-item -name PNK_Install -path c:\ -ItemType Directory
#new-item -name Scripts -path c:\ -ItemType Directory

# Set time zone to West Europe
#Set-TimeZone -Id "W. Europe Standard Time"

# Download files
#$ex2019  	= 'https://download.microsoft.com/download/b/f/7/bf7700c9-c2fd-40be-82cc-7c5330b5f981/ExchangeServer2019-x64-CU14.ISO'
#$ADConnect 	= 'https://download.microsoft.com/download/B/0/0/B00291D0-5A83-4DE7-86F5-980BC00DE05A/AzureADConnect.msi'

#Invoke-WebRequest -Uri $ex2019 -OutFile 'c:\PNK_Install\ExchangeServer2019-x64-CU14.ISO'
#Invoke-WebRequest -Uri $ADConnect -OutFile 'c:\PNK_Install\ExchangeServer2019-x64-CU14.ISO'

# Enable Ping in Windows Firewall
Enable-NetFirewallRule -displayName "File and Printer Sharing (Echo Request - ICMPv4-In)"
Enable-NetFirewallRule -displayName "File and Printer Sharing (Echo Request - ICMPv6-In)"

# Install needed Windows Services

    node "localhost"
    {

	LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = @("Web-Server","Web-Mgmt-Tools")
        }

	WindowsFeature Telnet
        {
            Ensure = "Present"
            Name   = "Telnet-Client"
        }


    }



}