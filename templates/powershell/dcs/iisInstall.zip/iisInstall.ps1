configuration IISInstall
{

Set-TimeZone -Id "W. Europe Standard Time"

    node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }
    }
}