configuration IISInstall 
{

# Import Modules
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'NetworkingDsc'

# Install IIS service


    Node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

	File DirectoryCopy
        {
            Ensure = "Present" # Ensure the directory is Present on the target node.
            Type = "Directory" # The default is File.
            DestinationPath = "C:\PNK_Install"
        }

	Firewall AddFirewallRule
        {
            Name                  = 'pnk_allow_all_prtg_monitoring_server'
            DisplayName           = 'pnk_allow_all_prtg_monitoring_server'
            Ensure                = 'Present'
            Enabled               = 'True'
            Profile               = ('Domain', 'Private')
            Direction             = 'Inbound'
	    RemoteAddress         = '10.10.10.10'
            RemotePort            = 'All Ports'
            LocalPort             = 'All Ports'
            Protocol              = 'ANY'
            Description           = 'Firewall rule for monitoring server'
        }
	
	Firewall EnableBuiltInFirewallRule
        {
            Name                  = 'File and Printer Sharing (Echo Request - ICMPv4-In)'
            Ensure                = 'Present'
            Enabled               = 'True'
        }

	
    }
}


