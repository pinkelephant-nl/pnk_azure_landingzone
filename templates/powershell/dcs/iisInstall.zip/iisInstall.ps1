configuration IISInstall 
{

    # Import Modules
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'NetworkingDsc'

    # Set correct timezone
    Set-TimeZone -Id "W. Europe Standard Time"

    # Install IIS service


    Node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

	File DirectoryCopy
        {
            Ensure = "Present" # Ensure the directory is Present on the target node.
            Type = "Directory" # The default is File.
            DestinationPath = "C:\PNK_Install"
        }

	Firewall AddFirewallRule
        {
            DisplayName           = 'pnk_allow_all_prtg_monitoring_server'
            Ensure                = 'Present'
            Enabled               = 'True'
            Profile               = 'Any'
            Direction             = 'Inbound'
	    Action	          = 'Allow'
	    LocalAddress          = 'Any'
	    RemoteAddress         = '10.10.10.10'
            RemotePort            = 'Any'
            LocalPort             = 'Any'
            Protocol              = 'Any'
            Description           = 'Firewall rule for monitoring server'
        }
	
	Firewall EnableBuiltInFirewallRule
        {
            Name                  = 'File and Printer Sharing (Echo Request - ICMPv4-In)'
            Ensure                = 'Present'
            Enabled               = 'True'
        }

	
    }
}


