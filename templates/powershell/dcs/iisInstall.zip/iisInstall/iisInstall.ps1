configuration IISInstall {

Import-DscResource -ModuleName 'PSDscResources'

# Create default folders
new-item -name PNK_Install -path c:\ -ItemType Directory
new-item -name Scripts -path c:\ -ItemType Directory

# Set time zone to West Europe
Set-TimeZone -Id "W. Europe Standard Time"



# Enable Ping in Windows Firewall
Enable-NetFirewallRule -displayName "File and Printer Sharing (Echo Request - ICMPv4-In)"
Enable-NetFirewallRule -displayName "File and Printer Sharing (Echo Request - ICMPv6-In)"

# Install needed Windows Services

Node localhost {
        WindowsFeatureSet ExampleWindowsFeatureSet {
            Name                 = @(
                'Telnet-Client'
                'RSAT-File-Services'
            )
            Ensure               = 'Present'
            IncludeAllSubFeature = $true
            LogPath              = 'C:\LogPath\Log.log'
        }
    }
}