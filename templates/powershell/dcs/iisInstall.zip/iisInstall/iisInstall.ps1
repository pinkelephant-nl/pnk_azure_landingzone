configuration IISInstall 
{

# Import Modules
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'NetworkingDsc'

# Add folders
    new-item -name PNK_Install -path c:\ -ItemType Directory
    new-item -name Scripts -path c:\ -ItemType Directory

# Install IIS service

    node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }
    }
}