configuration IISInstall {

Import-DscResource -ModuleName 'PSDscResources'

# Set time zone to West Europe
Set-TimeZone -Id "W. Europe Standard Time"


# Install needed Windows Services

Node localhost {
        WindowsFeatureSet ExampleWindowsFeatureSet {
            Name                 = @(
                'Telnet-Client'
                'RSAT-File-Services'
            )
            Ensure               = 'Present'
            IncludeAllSubFeature = $true
            LogPath              = 'C:\LogPath\Log.log'
        }
    }
}